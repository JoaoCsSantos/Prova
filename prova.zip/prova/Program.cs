﻿//Declaração de variavies
string nome;
int idade;
double altura, peso;
string resposta;

//Loop principal pra que o usuario tenha como repitir o relatorio varias vezes
do {
    //Solicita o nome da pessoa
    Console.WriteLine("Digite o nome da pessoa: ");
    //Lê a linha e armazena o nome na variavel 'nome'
    nome = Console.ReadLine();

    //Solicita ao usuario a idade
    Console.WriteLine("Digite a idade da pessoa: ");
    //Lê a idade do dada pelo usuario
    idade = int.Parse(Console.ReadLine());

    //Solicita ao usuario a altura
    Console.WriteLine("Me informe a altura (em metros): ");
    //Le a altura dada pelo usuario
    altura = double.Parse(Console.ReadLine());

    //Solicita o peso dado pelo usuario
    Console.WriteLine("Me informe o peso (em quilogramas): ");
    //Le o peso da pessoa
    peso = double.Parse(Console.ReadLine());

    //Calcura o IMC ultilizando a formula
    double imc = peso / (altura * altura);

    //Determina a categoria do IMC da pessoa de acordo com o valor calculado
    string categoriaIMC;
    if (imc < 18.5)
    {
        categoriaIMC = "Abaixo do peso";
    }
    else if (imc < 25)
    {
        categoriaIMC = "Normal";

    }
    else if (imc <30)
    {
        categoriaIMC = "Sobrepeso";
    }
    else
    {
        categoriaIMC = "Obeso";
    }

    //Determina a faixa etária da pessoa com base na idade
    string faixaEtaria;
    if (idade < 10)
    {
        faixaEtaria = "Criança";
    }
    else if (idade >= 10 && idade < 20)
    {
        faixaEtaria = "Adolescente";
    }
    else if (idade >= 20 && idade < 30)
    {
        faixaEtaria = "Adulto";
    }
    else
    {
        faixaEtaria = "Idoso";
    }

    //Imprime o relatorio final utilizando interpolação de strings pra formatar os dados
    Console.WriteLine($"Nome: {nome}");
    Console.WriteLine($"Idade: {idade}");
    Console.WriteLine($"IMC: {imc:F2} - {categoriaIMC}");
    Console.WriteLine($"Faixa Etária: {faixaEtaria}");

    //Pergunta ao usuario se ele deseja gerar um novo relatorio para outra pessoa
    Console.WriteLine("Deseja gerar um novo relatorio para outra pessoa? (s/n)");
    //Le a resposta
    resposta = Console.ReadLine();
    //convert a resposta para minusculas e verifica se é "s", se sim o loop continua se for "n" encerra o programa
}while (resposta.ToLower()=="s");